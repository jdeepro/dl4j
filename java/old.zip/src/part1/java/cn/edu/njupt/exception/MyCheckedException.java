package cn.edu.njupt.exception;

public class MyCheckedException extends Throwable {
    MyCheckedException(String msg) {
        super(msg);
    }
}
