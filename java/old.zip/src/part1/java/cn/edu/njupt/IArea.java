package cn.edu.njupt;

public interface IArea {
    float PI = 3.15f;
    float area();
}
