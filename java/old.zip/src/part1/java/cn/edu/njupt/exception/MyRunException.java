package cn.edu.njupt.exception;

public class MyRunException extends RuntimeException {
    MyRunException(String msg) {
        super(msg);
    }
}
