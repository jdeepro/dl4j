package part1.dl4j;

import javafx.scene.chart.ScatterChart;
import org.knowm.xchart.BitmapEncoder;
import org.knowm.xchart.QuickChart;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XYChart;

import java.io.IOException;

public class Boston {
	public static void main(String[] args) throws IOException {
		double[] xData = new double[] {6.575, 6.421, 7.185, 6.998, 7.147, 6.43, 6.012, 6.172, 5.631 };
		double[] yData = new double[] {24, 21.6, 34.7, 33.4, 36.2, 28.7, 22.9, 27.1, 16.5};

		// Create Chart
		ScatterChart chart = ScatterChart("Sample Chart", "X", "Y", "y(x)", xData, yData);

		// Show it
		new SwingWrapper(chart).displayChart();

		// Save it
		BitmapEncoder.saveBitmap(chart, "./Sample_Chart", BitmapEncoder.BitmapFormat.PNG);

		// or save it in high-res
		BitmapEncoder.saveBitmapWithDPI(chart, "./Sample_Chart_300_DPI", BitmapEncoder.BitmapFormat.PNG, 300);
	}
}