package cn.edu.njupt.calculus;

public class TanH implements ICalculus {
    @Override
    public double function(double value) {
        return 0;
    }

    @Override
    public double derivative(double value) {
        return 0;
    }
}
